import React, { useState, useEffect } from "react";
import { BrowserRouter as Router, Routes, Route, Link } from "react-router-dom";
import axios from "axios";

function Home() {
  return (
    <section style={{ textAlign: "center", padding: 20, backgroundColor: "#f0f8ff" }}>
      <h1 style={{ fontSize: 32, color: "#1e3a8a" }}>Baya Positive Académie</h1>
      <p style={{ fontSize: 18 }}>منصة دروس خصوصية في جميع المواد موجّهة للتلاميذ</p>
      <Link to="/register"><button>ابدأ التسجيل</button></Link>
    </section>
  );
}

function Register() {
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [level, setLevel] = useState("");
  const handleRegister = async () => {
    try {
      await axios.post("http://localhost:4000/api/students", { name, email, level });
      alert("تم التسجيل بنجاح");
    } catch (error) {
      alert("حدث خطأ أثناء التسجيل");
    }
  };
  return (
    <div style={{ maxWidth: 400, margin: "20px auto" }}>
      <h2 style={{ textAlign: "center" }}>تسجيل تلميذ</h2>
      <input placeholder="اسم التلميذ" value={name} onChange={e => setName(e.target.value)} /><br />
      <input placeholder="البريد الإلكتروني" value={email} onChange={e => setEmail(e.target.value)} /><br />
      <input placeholder="المستوى الدراسي" value={level} onChange={e => setLevel(e.target.value)} /><br />
      <button onClick={handleRegister}>تسجيل</button>
    </div>
  );
}

function Dashboard() {
  const [bookings, setBookings] = useState([]);
  useEffect(() => {
    axios.get("http://localhost:4000/api/bookings").then(res => setBookings(res.data));
  }, []);
  return (
    <div style={{ padding: 20 }}>
      <h2>لوحة التلميذ</h2>
      <ul>{bookings.map((b, i) => <li key={i}>{b.subject} - {b.date} - {b.time}</li>)}</ul>
    </div>
  );
}

function Booking() {
  const [subject, setSubject] = useState("");
  const [date, setDate] = useState("");
  const [time, setTime] = useState("");
  const handleBooking = async () => {
    try {
      await axios.post("http://localhost:4000/api/bookings", { subject, date, time });
      alert("تم الحجز بنجاح");
    } catch (error) {
      alert("فشل الحجز");
    }
  };
  return (
    <div style={{ maxWidth: 400, margin: "20px auto" }}>
      <h2>حجز درس</h2>
      <select value={subject} onChange={e => setSubject(e.target.value)}>
        <option>اختر المادة</option>
        <option>رياضيات</option>
        <option>فرنسية</option>
      </select><br />
      <input type="date" value={date} onChange={e => setDate(e.target.value)} /><br />
      <input type="time" value={time} onChange={e => setTime(e.target.value)} /><br />
      <button onClick={handleBooking}>احجز الآن</button>
    </div>
  );
}

function Videos() {
  const [videos, setVideos] = useState([]);
  useEffect(() => {
    axios.get("http://localhost:4000/api/videos").then(res => setVideos(res.data));
  }, []);
  return (
    <div style={{ padding: 20 }}>
      <h2>دروس فيديو</h2>
      <ul>{videos.map((v, i) => <li key={i}><a href={v.link}>{v.title}</a></li>)}</ul>
    </div>
  );
}

export default function App() {
  return (
    <Router>
      <nav style={{ backgroundColor: "#1e3a8a", padding: 10, color: "white" }}>
        <Link to="/" style={{ margin: 10, color: "white" }}>الرئيسية</Link>
        <Link to="/register" style={{ margin: 10, color: "white" }}>تسجيل</Link>
        <Link to="/dashboard" style={{ margin: 10, color: "white" }}>لوحة التلميذ</Link>
        <Link to="/booking" style={{ margin: 10, color: "white" }}>حجز درس</Link>
        <Link to="/videos" style={{ margin: 10, color: "white" }}>دروس فيديو</Link>
      </nav>
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/register" element={<Register />} />
        <Route path="/dashboard" element={<Dashboard />} />
        <Route path="/booking" element={<Booking />} />
        <Route path="/videos" element={<Videos />} />
      </Routes>
    </Router>
  );
}
