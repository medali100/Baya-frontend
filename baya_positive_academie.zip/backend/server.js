const express = require("express");
const cors = require("cors");
const app = express();
app.use(cors());
app.use(express.json());

let students = [], bookings = [], videos = [
  { title: "رياضيات - الكسور", link: "#" },
  { title: "فرنسية - Les verbes", link: "#" }
];

app.post("/api/students", (req, res) => {
  students.push(req.body);
  res.send({ status: "ok" });
});

app.post("/api/bookings", (req, res) => {
  bookings.push(req.body);
  res.send({ status: "booked" });
});

app.get("/api/bookings", (req, res) => {
  res.send(bookings);
});

app.get("/api/videos", (req, res) => {
  res.send(videos);
});

app.listen(4000, () => console.log("Server running on port 4000"));
